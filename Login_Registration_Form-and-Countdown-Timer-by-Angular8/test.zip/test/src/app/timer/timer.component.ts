import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timer',
  template: `
  <nav class="navbar navbar-dark bg-dark">
  <button class="btn btn-primary" style="margin:5px;" type="submit" (click)=logOut()>LogOut</button>
</nav>
  <body>
  
  <div class="container-fluid" style="text-align:center">
  <h4>World's Largest Developer Expo Series</h4>
  <h2>Gives you all you need to know</h2>
  <h1>JUNE 05</h1>
  <h1>2021</h1>
  <p id="demo"></p>
  </div>
  <p id="expire"></p>
  </body>
  
  `,
  styleUrls: ['./timer.component.css']
})
export class TimerComponent implements OnInit {


  constructor() { }

  ngOnInit() {
  }

  logOut()
  {
    sessionStorage.clear();
    clearInterval(this.x);
  }


 x = setInterval(function() {
  var countDownDate = new Date("Nov 19, 2019 20:17:50").getTime();


  var now = new Date().getTime();
    
  var distance = countDownDate - now;
    
 
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
 
  document.getElementById("demo").innerHTML = days + " Days :" + hours + " Hours : "
  + minutes + " Minutes :" + seconds + " Seconds .";

    
 
  if (distance < 0) {
    document.getElementById("demo").innerHTML="";
    document.getElementById("expire").innerHTML = "EXPIRED";
  }
}, 1000);

    
  }
