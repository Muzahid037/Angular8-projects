import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AppComponent } from 'src/app/app.component';


@Component({
  selector: 'app-registration',
  template: `

  
  <div class="container-fluid" style="text-align:center">

  

    <h6>Registration</h6>
  
    <form>
  
     <div class="form-group">
       <label>Email Address</label>
       <input type="text"  name="email" #SignUpEmail class="form-control">
     </div>
  
     <div class="form-group">
       <label>Username</label>
       <input type="text"  name="username" #SignUpUsername class="form-control">
     </div>
     
     <div class="form-group">
     <label>Password</label>
     <input type="text" name="password" #SignUpPassword class="form-control">
     </div>
  
     <button class="btn btn-primary" style="margin:5px;" type="submit" (click)=gotoLoginPage()>SIGN IN</button>
     <button class="btn btn-primary" style="margin:5px;" type="submit" (click)=insertRegisterData(SignUpEmail.value,SignUpUsername.value,SignUpPassword.value)>SIGN UP</button>
     </form>

     <p id="demo"></p>

    </div>
  

  `,
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  @Output() public childEvent = new EventEmitter();


  constructor() { }

  ngOnInit() {
  }

  gotoLoginPage() {
    this.childEvent.emit(true);

  }


  insertRegisterData(email, username, password) {

    var flag = 1;
    var us = 1;
    var em = 1;

    var users = JSON.parse(localStorage.getItem('Users')) || [];

    for (var i = 0; i < users.length; i++) {
      if (users[i].Email == email) {
        flag = 0;
        em = 0;
      }
      if (users[i].Username == username) {
        flag = 0;
        us = 0;
      }
    }

    if (email == "" || username == "" || password == "") {
      document.getElementById("demo").innerHTML = "All Filed Required";

      setTimeout(function () {
        document.getElementById("demo").innerHTML = '';
      }, 2000);
    }

    else if (flag == 0) {
      if (us == 0) {
        document.getElementById("demo").innerHTML = "Username taken";

        setTimeout(function () {
          document.getElementById("demo").innerHTML = '';
        }, 2000);
      }
      else {
        document.getElementById("demo").innerHTML = "Email is already used";

        setTimeout(function () {
          document.getElementById("demo").innerHTML = '';
        }, 2000);
      }
    }

    else {
      var userData = { Username: username, Email: email, Password: password };
      users.push(userData);
      localStorage.setItem('Users', JSON.stringify(users));

      document.getElementById("demo").innerHTML = "Signed Up!!!Go to Sign In";

      setTimeout(function () {
        document.getElementById("demo").innerHTML = '';
      }, 2000);
    }



  }

}
