import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  template: `
<div *ngIf = "loggedIn()">
<app-timer></app-timer>
</div>
<div *ngIf="!loggedIn()">
<div *ngIf="!message">
    <app-registration (childEvent)="checkMessage($event)"></app-registration>
</div>

<div *ngIf="message">
        <app-login (childEvent)="checkMessage($event)"></app-login>
</div>
        
</div> 
    
  `,

  styleUrls: ['./app.component.css']
})


export class AppComponent {
 
  public message=false;

  checkMessage(x)
  {
     this.message = x;
  }
  loggedIn()
  {
     if(sessionStorage.getItem('currentUser'))
     {
       return true;
     }
     else
     {
       return false;
     }
  }
  
}
