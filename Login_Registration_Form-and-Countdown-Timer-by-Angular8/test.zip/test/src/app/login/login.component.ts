import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-login',
  template: `
  <div class="container-fluid" style="text-align:center">

<h6>Sign In</h6>

  <form >
   <div class="form-group">
     <label>Username</label>
     <input type="text"  name="username" #SignInUsername class="form-control">
   </div>
   
   <div class="form-group">
   <label>Password</label>
   <input type="text" name="password" #SignInPassword class="form-control">
   </div>

   <button class="btn btn-primary" style="margin:5px;" type="submit" (click)=signInFunction(SignInUsername.value,SignInPassword.value)>SIGN IN</button>
   <button class="btn btn-primary" style="margin:5px;" type="submit" (click)=gotoRegistrationPage()>SIGN UP</button>
  
   </form>

   </div>
  `,
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    allow=0;

  @Output() public childEvent = new EventEmitter();

  @Output() public childEvent2 = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  gotoRegistrationPage() {
    this.childEvent.emit(false);
  }


  signInFunction(username, password) {

    var users = JSON.parse(localStorage.getItem('Users')) || [];

    for (var i = 0; i < users.length; i++) {

      if (users[i].Username == username && users[i].Password == password) {
        sessionStorage.setItem('currentUser', username);
         this.childEvent2.emit(true);
      }

    }
  }



}
